# Jayraj Lakkad — Portfolio (Vite + React + Tailwind)

This is a single-page portfolio built with Vite, React and Tailwind CSS.

## Quick start

```bash
npm install
npm run dev       # dev server
npm run build     # production build (output: dist/)
npm run preview   # preview production build
```

## Deploy

- Push this repo to GitHub and use GitHub Pages (with Actions) or deploy to Vercel/Netlify.
- Ensure `public/Jayraj_Resume_20251108.pdf` exists — it's included in this package.
