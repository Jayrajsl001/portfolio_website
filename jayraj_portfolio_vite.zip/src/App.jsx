import React from 'react';
import Portfolio from './components/Portfolio';

export default function App(){
  return <Portfolio />;
}
